package com.example.CryptoPortfolioTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CryptoPortfolioTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
